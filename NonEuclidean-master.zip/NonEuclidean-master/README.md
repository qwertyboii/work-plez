# NonEuclidean
A NonEuclidean rendering engine for Windows, written in C++ OpenGL.
To see what this code is about, check out this video:
https://youtu.be/kEB11PQ9Eo8

## Source Code Dependencies
Add glew-2.1.0 to the main directory

## Controls
* **Mouse** - Look around
* **AWSD** - Movement
* **1 - 7** - Switch between different demo rooms
* **Alt + Enter** - Toggle Fullscreen
* **Esc** - Exit demo
